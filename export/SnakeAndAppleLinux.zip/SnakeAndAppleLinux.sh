#!/bin/sh
printf '\033c\033]0;%s\a' Snake and Apple
base_path="$(dirname "$(realpath "$0")")"
"$base_path/SnakeAndAppleLinux" "$@"
